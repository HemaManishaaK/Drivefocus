# SUBMISSION_CHECKLIST.md

Maps every requirement from the Rime Hackathon PS's "What to submit" and
"Eligibility and integrity" sections to what's in this repository right now.

## What to submit (from the PS)

| Requirement | Status | Notes |
|---|---|---|
| **Demo** — recorded, ≤4–5 min, shows user/problem, normal flow, hard voice problem, one stress case, result, active speech provider | 🟡 **Script ready, not recorded** | Follow `DEMO_SCRIPT.md` exactly — it's timestamped and maps each segment to a PS requirement. Needs a live Rime API key and a screen recording tool. |
| **Working code** — source repo judges can inspect + working demo link/recording | 🟢 **Repo ready** | This zip. All logic (Rime client, orchestrator, decision engine) is real, runnable code — not a mockup. Judges can `npm start` and reproduce the scenario live. |
| **README** — setup, architecture, third-party services, limitations, failure behavior, exact Rime model ID/speaker/language/endpoint/audio format/transport | 🟢 **Complete** | See `README.md`. All Rime config values are stated explicitly and are environment-variable-overridable. |
| **RIME_EVIDENCE.md** — hard voice claim, acceptance test, procedure, result, limitations, repeatable command | 🟡 **Structure complete, numbers pending** | `npm run test:acceptance` auto-generates real numbers — currently placeholders marked `TBD`. Must be filled in with real output before submission. |
| **Configuration hygiene** — env example with placeholders only, passes org preflight | 🟢 **Complete** | `.env.example` contains only placeholder values. No real credentials exist anywhere in this repo. |
| **At least 3 recent primary papers (2022–2026)** *(this is a Pathway-track requirement, not explicitly required by the Rime track — see note below)* | ⚪ N/A for Rime track | The Rime PS does not list a papers requirement; this applies to the DataForge Pathway track only. Confirm with organizers if Rime track also expects this. |
| **Source and license record** for code, data, weights, graphics, fonts, reused components | 🟢 **Complete** | See README "Credits / licenses" section — all dependencies are MIT-licensed npm packages; Rime used under its API terms. |
| **AI assistance disclosure** | 🟢 **Complete** | See README "AI assistance disclosure" section. |

## Eligibility and integrity (disqualifiers to avoid)

| Disqualifier | Status |
|---|---|
| No verifiable Rime integration in code | ✅ Avoided — `rimeClient.js` is a real, functional WebSocket client against Rime's actual API |
| Rime used only for incidental speech (welcome message, etc.) | ✅ Avoided — Rime is the *only* spoken output for every navigation instruction and every decision outcome |
| Static screens / concept deck / scripted mock with no working product | ✅ Avoided — this is a running Node.js application with real state management |
| Missing demo | 🟡 **Action required** — must record per `DEMO_SCRIPT.md` |
| Exposed credential/secret | ✅ Avoided — `.env` is gitignored, `.env.example` has placeholders only |
| Model/voice/language combo failing event preflight | 🟡 **Action required** — verify `coda`/`astra` are still current in Rime's live catalog at submission time (PS explicitly warns against copying a stale speaker list) |

## What your team must still do before submitting

1. **Get a real Rime API key** and add it to a local `.env` (never commit it).
2. **Run the app once** (`npm start`) to confirm it works end-to-end against
   live Rime, watching `http://localhost:8080`.
3. **Run the acceptance test** (`npm run test:acceptance`) and paste the real
   output table into `RIME_EVIDENCE.md`, replacing the `TBD` placeholders.
4. **Verify the current model/voice/language** against Rime's live catalog
   (linked in the PS's starter resources) — update `.env` if `coda`/`astra`
   are no longer current.
5. **Record the demo** following `DEMO_SCRIPT.md`.
6. **Deploy or prepare a local demo path** — the PS requires "a public
   artifact URL that opens without sign-in." This repo runs locally by
   default; if a public URL is required, deploy `src/server.js` to a host
   (Render/Railway/Fly.io all support long-lived WebSocket connections) and
   update the README with the live link.
7. **Push to a public git repository** and link it in your submission form.
8. **Team must be able to defend every component live** — read through
   `rimeClient.js`, `orchestrator.js`, and `relevanceEngine.js` together as a
   team before the judging session; be ready to explain the heard/unheard
   word-fencing logic and the four-way decision rules without notes.

## File manifest

```
drivefocus/
├── README.md                  — architecture, setup, disclosures, config
├── RIME_EVIDENCE.md            — claim, acceptance test, results (fill in TBDs)
├── DEMO_SCRIPT.md              — timestamped recording script
├── SUBMISSION_CHECKLIST.md     — this file
├── .env.example                — placeholder config only
├── package.json
├── events/
│   └── scenario.json           — simulated driver speech + hazard timeline
├── public/
│   └── index.html              — live demo UI (state + decision log)
└── src/
    ├── rimeClient.js           — Rime WebSocket streaming + word-timestamp fencing
    ├── orchestrator.js         — state machine wiring events → Rime → decisions
    ├── relevanceEngine.js      — DISCARD/REPLACE/REPEAT/RESUME rule engine
    ├── sttSimulator.js         — simulated input loader (documented STT swap point)
    ├── server.js               — Express + WebSocket server, runs the scenario
    └── acceptanceTest.js       — automated evidence generator (5-trial latency/accuracy)
```
