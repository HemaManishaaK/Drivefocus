# DEMO_SCRIPT.md

Recording plan for the required 4–5 minute demo video. The Rime PS requires
the demo to show: **the target user and problem, the normal end-to-end flow,
the selected hard voice problem, one deliberate stress/failure case, the
result or measurement, and which speech provider is active.** Every section
below is labeled with which requirement it satisfies.

Run `npm start`, open `http://localhost:8080`, and share that screen while
recording. Have `RIME_EVIDENCE.md` results already generated (`npm run
test:acceptance`) before filming, so you can show real numbers, not
"trust me" claims.

---

## [0:00–0:30] Target user and problem

**Say:** "DriveFocus is voice navigation for drivers. The problem: current
systems interrupt speech when something changes, but the interrupted
instruction can become outdated, get repeated pointlessly, or resume
mid-sentence in a confusing way — which increases cognitive load exactly
when a driver can least afford it."

**Show:** Nothing running yet — just state the problem plainly, maybe over
the README's architecture diagram.

*Satisfies: target user and problem.*

---

## [0:30–1:15] Normal end-to-end flow

**Say:** "Here's the normal flow — Rime speaking a navigation instruction
with no interruption."

**Show:** Start the app, let `nav1` ("In one kilometre, continue straight on
Main Street") play fully, uninterrupted. Point at the live state indicator
switching SPEAKING → IDLE.

**Say:** "Rime is generating every word you're hearing — this is the primary
spoken output, not a pre-recorded clip."

*Satisfies: normal end-to-end flow, active speech provider (Rime, stated explicitly).*

---

## [1:15–2:00] The hard voice problem, stated precisely

**Say:** "The hard voice problem we're solving is interruption and recovery
— but with a twist most implementations skip: we don't just stop and
guess what to do next. We use Rime's word-level timestamps to know *exactly*
which words the driver already heard, then run that through a rule-based
decision engine that picks one of four outcomes: discard, replace, repeat,
or resume."

**Show:** Briefly show `relevanceEngine.js` on screen — the four ACTION
constants and the rule comments — so judges see this is a real decision
system, not a hardcoded response.

*Satisfies: selected hard voice problem, stated explicitly and precisely.*

---

## [2:00–3:15] Deliberate stress case — the roadblock example

**Say:** "Now the stress case. Nav is mid-instruction: 'In three hundred
metres, turn left onto—' and the driver interrupts with a roadblock report."

**Show:** Let `nav2` start, then let `interrupt1` fire at 6200ms (roadblock).
Point at the UI log in real time:
- `interrupt_received`
- `utterance_cancelled` — call out the `heardText` / `unheardText` split
  visible in the log (this proves the timestamp tracking is real)
- `decision` — show it logs `REPLACE` with the stated reason
- `speak_started` — the new rerouted instruction plays

**Say:** "Notice the driver never hears the invalidated street name — the
system doesn't finish the sentence and then correct itself, it cuts in
before the outdated information is spoken."

*Satisfies: one deliberate stress/failure case.*

---

## [3:15–4:00] A second case — proving it doesn't overreact

**Say:** "It's just as important that the system doesn't overreact to every
interruption. Here the driver asks an unrelated question late into a long
instruction."

**Show:** Let `interrupt4` fire (the "turn down the volume" command late into
`nav5`). Point at the decision log showing `RESUME` — the system finishes
only the unheard remainder instead of needlessly repeating the whole
sentence or discarding valid navigation info.

*Satisfies: demonstrates the decision engine handles more than the single
scripted headline case — strengthens "hard voice engineering" scoring.*

---

## [4:00–4:45] Result / measurement

**Say:** "We measured this across 5 automated trials against a live Rime
connection." Show the `RIME_EVIDENCE.md` results table with real numbers
(cancel latency, decision-accuracy rate, and confirmation that no stale
audio ever leaked through after a cancel).

*Satisfies: result or measurement, backed by reproducible evidence.*

---

## [4:45–5:00] Close — honesty disclosure

**Say:** "To be transparent: the driver's speech and the roadblock/hazard
detection in this demo are scripted inputs, standing in for real
speech-to-text and traffic data — documented in our README. What's fully
live is the entire Rime pipeline: streaming synthesis, word-level timestamp
tracking, cancellation, and the decision engine built on top of it."

*Satisfies: PS's accuracy/no-overclaiming requirement — disclose what's live
vs. simulated on camera, not just in the README.*

---

## Recording checklist

- [ ] Run `npm run test:acceptance` beforehand and have real numbers ready
- [ ] Confirm `.env` has a valid `RIME_API_KEY` (never show this on screen)
- [ ] Do a full dry run first — the scenario timing is fixed, so know when
      each event fires before recording live
- [ ] Keep total runtime under 5:00
- [ ] Export as MP4, upload, and link it in your submission package
