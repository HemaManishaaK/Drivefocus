# DriveFocus — Interruption-Safe Voice Navigation

## One-sentence claim

When a high-priority event interrupts an in-progress Rime-spoken navigation
instruction, the system stops audio within milliseconds, determines exactly
which words the driver already heard using Rime's word-level timestamps, and
decides — via an explainable rule set — to **discard**, **replace**, **repeat**,
or **resume** the instruction, such that the driver never hears outdated or
conflicting information.

## Intended learner / user

A driver using turn-by-turn voice navigation who cannot look at a screen
while driving. Voice is not a convenience layer here — it is the only usable
input/output channel for the target situation.

## Why removing voice breaks this product

There is no functional fallback. A driver cannot safely read a screen for
route updates while driving; the entire value of the product collapses
without spoken output.

## Architecture

```
events/scenario.json (simulated driver speech + hazard events)
        │
        ▼
Orchestrator (src/orchestrator.js)
   - tracks SPEAKING / IDLE state
   - on interrupt: calls RimeClient.cancel()
        │
        ▼
RimeClient (src/rimeClient.js)
   - streams TTS via Rime's WebSocket JSON API (wss://users-ws.rime.ai/ws3)
   - tracks word-level timestamps as audio streams
   - on cancel(): returns { heardText, unheardText, heardWordCount, totalWordCount }
        │
        ▼
relevanceEngine.js
   - decideAction(cancelReport, interruptEvent) -> DISCARD | REPLACE | REPEAT | RESUME
        │
        ▼
Orchestrator speaks the resulting text (if any) via RimeClient.speak()
```

## What's live vs. simulated (full disclosure)

| Component | Status |
|---|---|
| Rime TTS streaming + word-level timestamps | **Live** — real Rime API calls, real audio, real timestamp data |
| Cancel/fence logic (`rimeClient.js`) | **Live** — real WebSocket cancel behavior against the live connection |
| Relevance decision engine | **Live** — real rule evaluation, deterministic and testable |
| Driver speech ("There is a roadblock ahead...") | **Simulated** — scripted event in `events/scenario.json`, not real STT. See `src/sttSimulator.js` for the documented swap point to a real speech recognizer (e.g. Deepgram streaming STT). |
| Roadblock/hazard detection | **Simulated** — scripted event, not a real traffic/routing API. |
| Rerouted instruction text | **Simulated** — pre-written replacement text, not a live routing engine (e.g. Mapbox/Google Directions) call. |

This project proves the **interrupt → evaluate → decide → speak pipeline**
end-to-end against a real Rime connection. It does not claim to have built
production-grade speech recognition, hazard detection, or routing — those
are out of scope for a one-week build and are clearly scripted inputs feeding
a real decision-and-speech pipeline.

## Setup

```bash
npm install
cp .env.example .env
# fill in RIME_API_KEY in .env
npm start
# open http://localhost:8080 to watch the live decision log + state
```

To reproduce the measured evidence in `RIME_EVIDENCE.md`:

```bash
npm run test:acceptance
# runs the scenario 5x against a live Rime connection and writes
# acceptance_results.json with per-interrupt latency and decision accuracy
```

## Rime configuration used

- Model: `coda` (flagship, lowest latency — configurable via `RIME_MODEL_ID`)
- Speaker: `astra` (configurable via `RIME_SPEAKER`)
- Endpoint: `wss://users-ws.rime.ai/ws3` (WebSocket JSON streaming)
- Audio format: `mp3` (configurable via `RIME_AUDIO_FORMAT`)
- Transport: WebSocket, persistent connection, word-level timestamps enabled

Confirm these values are still current against Rime's live model/voice
catalog at submission time, per the hackathon's "use a current production
configuration" rule.

## Known limitations

- The relevance engine's thresholds (30% / 70% heard-fraction cutoffs for
  REPEAT vs. RESUME) are a reasonable starting heuristic, not derived from
  user studies. A real product would tune these against actual driver
  comprehension testing.
- RESUME on a mid-sentence fragment can still sound grammatically abrupt in
  some phrasings (e.g. resuming right after a comma). The engine defaults to
  REPEAT rather than RESUME for partial (30–70%) heard fractions specifically
  to avoid this failure mode, but the boundary is a judgment call, not a hard
  rule derived from linguistics.
- Driver speech is scripted (see disclosure above) — real-world speech
  recognition accuracy, background road noise, and false-positive interrupts
  are not evaluated in this build.
- No real routing engine — replacement instruction text is pre-authored per
  scenario, not computed from live map data.

## Credits / licenses

- Rime TTS: https://docs.rime.ai — used under Rime's API terms.
- ws, express, dotenv: MIT-licensed npm packages.
- All code in this repository is original, written for this hackathon
  submission with AI assistance disclosed below.

## AI assistance disclosure

This project's architecture, code (rimeClient.js, orchestrator.js,
relevanceEngine.js, server.js, sttSimulator.js, acceptanceTest.js, UI, and
this README), and evidence methodology were drafted with AI assistance
(Claude). The team is responsible for understanding, testing, and defending
every component, per the hackathon's technical ownership requirement.
