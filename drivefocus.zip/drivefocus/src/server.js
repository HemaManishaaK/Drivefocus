// server.js
//
// Runs events/scenario.json through the Orchestrator, streams Rime audio and
// live decision-log entries to a minimal browser UI, and exposes /api/log so
// acceptanceTest.js can pull the full timestamped record after a run.

import "dotenv/config";
import express from "express";
import { WebSocketServer } from "ws";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";

import { RimeClient } from "./rimeClient.js";
import { Orchestrator } from "./orchestrator.js";
import { loadScenario } from "./sttSimulator.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
app.use(express.static(path.join(__dirname, "..", "public")));

const server = createServer(app);
const wss = new WebSocketServer({ server });

const PORT = process.env.PORT || 8080;

let orchestratorRef = null;

async function main() {
  const apiKey = process.env.RIME_API_KEY;
  if (!apiKey) {
    console.error("Missing RIME_API_KEY. Copy .env.example to .env and fill it in.");
    process.exit(1);
  }

  const rime = new RimeClient({
    apiKey,
    speaker: process.env.RIME_SPEAKER || "astra",
    modelId: process.env.RIME_MODEL_ID || "coda",
    audioFormat: process.env.RIME_AUDIO_FORMAT || "mp3",
  });

  await rime.connect();
  console.log(`Connected to Rime (model: ${rime.modelId}, speaker: ${rime.speaker})`);

  const orchestrator = new Orchestrator(rime);
  orchestratorRef = orchestrator;

  const clients = new Set();
  wss.on("connection", (ws) => {
    clients.add(ws);
    ws.on("close", () => clients.delete(ws));
  });

  function broadcastJSON(obj) {
    const payload = JSON.stringify(obj);
    for (const ws of clients) if (ws.readyState === 1) ws.send(payload);
  }

  orchestrator.on("log", (entry) => broadcastJSON({ type: "log", entry, state: orchestrator.state }));

  rime.on("audioChunk", (chunk) => {
    for (const ws of clients) if (ws.readyState === 1) ws.send(chunk); // binary audio frame
  });

  rime.on("cancelled", (report) => broadcastJSON({ type: "audio_cancel", report }));

  app.get("/api/log", (_req, res) => res.json(orchestrator.getLog()));

  server.listen(PORT, () => console.log(`DriveFocus UI + WS server on http://localhost:${PORT}`));

  // --- Run the scenario ---
  const { events } = loadScenario(path.join(__dirname, "..", "events", "scenario.json"));
  console.log(`Loaded ${events.length} scenario events.`);
  broadcastJSON({ type: "run_start", at: Date.now() });

  for (const event of events) {
    setTimeout(() => orchestrator.handleEvent(event), event.atMs);
  }
}

main().catch((err) => {
  console.error("Fatal startup error:", err);
  process.exit(1);
});

export function getOrchestrator() {
  return orchestratorRef;
}
