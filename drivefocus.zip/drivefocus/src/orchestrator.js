// orchestrator.js
//
// Owns the state machine described in the problem statement:
//   navigation instruction speaking -> interrupt arrives -> Rime.cancel()
//   -> relevanceEngine.decideAction() -> speak the resulting action's text (if any)
//
// Every transition is timestamped into `log`, which both the acceptance test
// and RIME_EVIDENCE.md draw their numbers from.

import { EventEmitter } from "events";
import { decideAction, ACTION } from "./relevanceEngine.js";

export const STATE = {
  IDLE: "IDLE",
  SPEAKING: "SPEAKING",
};

export class Orchestrator extends EventEmitter {
  constructor(rimeClient) {
    super();
    this.rime = rimeClient;
    this.state = STATE.IDLE;
    this.log = [];

    this.rime.on("done", () => this._onDone());
  }

  _record(type, data = {}) {
    const entry = { t: Date.now(), type, ...data };
    this.log.push(entry);
    this.emit("log", entry);
    return entry;
  }

  handleEvent(event) {
    if (event.kind === "navigation") return this._handleNavigation(event);
    if (event.kind === "interrupt") return this._handleInterrupt(event);
  }

  _handleNavigation(event) {
    this._record("nav_event_received", { id: event.id, text: event.text });

    if (this.state === STATE.SPEAKING) {
      // A new navigation instruction while one is already playing should not
      // normally happen in this scenario design (instructions are spaced out),
      // but if it does, queue-drop in favor of the newer instruction's relevance
      // being handled the next time an interrupt or completion occurs.
      this._record("nav_event_dropped_busy", { id: event.id });
      return;
    }

    this._speak(event.text, { sourceId: event.id, sourceKind: "navigation" });
  }

  _handleInterrupt(event) {
    this._record("interrupt_received", {
      id: event.id,
      source: event.source,
      spokenText: event.spokenText,
    });

    if (this.state !== STATE.SPEAKING) {
      // No active utterance to cancel. If the interrupt carries a new
      // instruction (e.g. hazard detected while idle), speak it directly.
      if (event.newInstructionText) {
        this._speak(event.newInstructionText, { sourceId: event.id, sourceKind: "interrupt_direct" });
      }
      return;
    }

    const cancelStart = Date.now();
    const cancelReport = this.rime.cancel();
    this._record("utterance_cancelled", {
      interruptId: event.id,
      cancelLatencyMs: Date.now() - cancelStart,
      heardText: cancelReport.heardText,
      unheardText: cancelReport.unheardText,
      heardWordCount: cancelReport.heardWordCount,
      totalWordCount: cancelReport.totalWordCount,
    });

    this.state = STATE.IDLE;

    const decision = decideAction(cancelReport, event);
    this._record("decision", {
      interruptId: event.id,
      action: decision.action,
      reason: decision.reason,
    });

    if (decision.action === ACTION.DISCARD) {
      // Explicitly speak nothing further about the discarded instruction.
      return;
    }

    this._speak(decision.nextText, {
      sourceId: event.id,
      sourceKind: `interrupt_${decision.action.toLowerCase()}`,
    });
  }

  _speak(text, meta) {
    this.state = STATE.SPEAKING;
    const utteranceId = this.rime.speak(text);
    this._record("speak_started", { utteranceId, text, ...meta });
  }

  _onDone() {
    this._record("utterance_done", {});
    this.state = STATE.IDLE;
  }

  getLog() {
    return this.log;
  }
}
