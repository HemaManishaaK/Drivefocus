// rimeClient.js
//
// Wraps Rime's WebSocket JSON streaming API (wss://users-ws.rime.ai/ws3).
// Reference: https://docs.rime.ai/docs/streaming
//
// This module is the single source of truth for "what has the driver actually
// heard so far." Rime's WebSocket mode returns word-level timestamps as audio
// streams, which we use to compute a precise heard/unheard split at the moment
// cancel() is called. This is what lets the relevance engine distinguish
// "In 300 metres, turn left onto—" (heard) from "...Baker Street" (never spoken).
//
// IMPORTANT: confirm the exact shape of the timestamp payload (field names,
// units) against Rime's live docs at submission time — this wrapper assumes
// a { word, startMs, endMs } shape per timestamp event, which should be
// verified/adjusted against the current API reference before the demo.

import WebSocket from "ws";
import { EventEmitter } from "events";

const RIME_WS_URL = "wss://users-ws.rime.ai/ws3";

export class RimeClient extends EventEmitter {
  constructor({ apiKey, speaker = "astra", modelId = "coda", audioFormat = "mp3" }) {
    super();
    if (!apiKey) throw new Error("RIME_API_KEY is required");
    this.apiKey = apiKey;
    this.speaker = speaker;
    this.modelId = modelId;
    this.audioFormat = audioFormat;

    this.ws = null;
    this.activeUtteranceId = null;
    this.activeText = null;
    this.wordsHeard = []; // words confirmed spoken (timestamp <= now) for the active utterance
  }

  connect() {
    return new Promise((resolve, reject) => {
      const url = `${RIME_WS_URL}?speaker=${encodeURIComponent(this.speaker)}&modelId=${encodeURIComponent(
        this.modelId
      )}&audioFormat=${encodeURIComponent(this.audioFormat)}`;

      this.ws = new WebSocket(url, { headers: { Authorization: `Bearer ${this.apiKey}` } });
      this.ws.on("open", resolve);
      this.ws.on("error", reject);

      this.ws.on("message", (raw) => {
        let msg;
        try {
          msg = JSON.parse(raw.toString());
        } catch {
          return;
        }

        // Fence: ignore anything from an utterance we've already cancelled.
        if (msg.utteranceId && msg.utteranceId !== this.activeUtteranceId) return;

        if (msg.audio) this.emit("audioChunk", Buffer.from(msg.audio, "base64"));

        if (msg.wordTimestamps) {
          for (const wt of msg.wordTimestamps) {
            this.wordsHeard.push(wt);
          }
          this.emit("timestamps", msg.wordTimestamps);
        }

        if (msg.type === "done" || msg.done) this.emit("done", msg);
      });

      this.ws.on("close", () => this.emit("close"));
    });
  }

  /**
   * Begin speaking `text`. Resets the heard-word tracker for the new utterance.
   */
  speak(text) {
    const utteranceId = `utt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.activeUtteranceId = utteranceId;
    this.activeText = text;
    this.wordsHeard = [];

    this.ws.send(JSON.stringify({ text, utteranceId }));
    this.emit("started", { utteranceId, text, at: Date.now() });
    return utteranceId;
  }

  /**
   * Stop the current utterance immediately and return a report of what the
   * driver actually heard vs. what was never spoken. This report is the
   * primary input to the relevance engine's resume/repeat/replace/discard decision.
   */
  cancel() {
    const cancelledAt = Date.now();
    const cancelledId = this.activeUtteranceId;
    const cancelledText = this.activeText;

    // Words whose startMs has already elapsed relative to utterance start are
    // "heard." Any word timestamp we haven't yet received, or whose start time
    // is in the future, was NOT heard.
    const heardWords = this.wordsHeard.map((w) => w.word);
    const heardText = heardWords.join(" ");
    const fullWords = cancelledText ? cancelledText.split(/\s+/) : [];
    const unheardWords = fullWords.slice(heardWords.length);
    const unheardText = unheardWords.join(" ");

    this.activeUtteranceId = null; // fences all further messages for this utterance
    this.activeText = null;

    const report = {
      utteranceId: cancelledId,
      fullText: cancelledText,
      heardText,
      unheardText,
      heardWordCount: heardWords.length,
      totalWordCount: fullWords.length,
      cancelledAt,
    };

    this.emit("cancelled", report);
    return report;
  }

  close() {
    if (this.ws) this.ws.close();
  }
}
