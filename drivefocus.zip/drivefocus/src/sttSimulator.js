// sttSimulator.js
//
// SIMULATED input source, disclosed as such in RIME_EVIDENCE.md and the README.
//
// In a real product this module would be replaced by:
//   - A streaming STT provider (e.g. Deepgram) listening for driver speech
//     like "there's a roadblock ahead" and running it through an intent classifier.
//   - A real routing/traffic API detecting road closures.
//
// For the hackathon build, both are replaced by a scripted event timeline
// (events/scenario.json) fired on a timer. This lets us prove the interrupt →
// evaluate → decide → speak pipeline deterministically and repeatably, which
// is what the acceptance test actually needs to measure — the pipeline's
// correctness and latency, not general-purpose speech recognition accuracy.
//
// Swap point: replace `loadScenario` + the setTimeout loop in server.js with
// a real STT stream emitting the same event shape shown in scenario.json.

import fs from "fs";

export function loadScenario(path) {
  const raw = fs.readFileSync(path, "utf-8");
  return JSON.parse(raw);
}
