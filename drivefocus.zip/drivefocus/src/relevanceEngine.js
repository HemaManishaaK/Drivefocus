// relevanceEngine.js
//
// Given a cancellation report (what the driver heard/didn't hear) and the
// interrupting event (roadblock, driver command, route change, etc.), decide
// what happens next: DISCARD, REPLACE, REPEAT, or RESUME.
//
// This is intentionally rule-based and explainable rather than a black-box
// classifier — the PS requires judges to be able to trace the system's
// behavior, and a clear rule set is easier to defend live and to test
// deterministically for the acceptance test.

export const ACTION = {
  DISCARD: "DISCARD", // interrupted instruction is fully invalidated, say nothing further about it
  REPLACE: "REPLACE", // same intent, but content must change (new route/turn)
  REPEAT: "REPEAT", // interrupted before driver heard anything meaningful; say it again
  RESUME: "RESUME", // interrupted near the end; remaining content is still accurate, finish it
};

/**
 * @param {object} cancelReport - output of RimeClient.cancel()
 * @param {object} interruptEvent - { type: "roadblock" | "reroute" | "driver_command" | "minor_update",
 *                                     invalidatesCurrentInstruction: boolean,
 *                                     newInstructionText?: string }
 * @returns {{ action: string, reason: string, nextText: string | null }}
 */
export function decideAction(cancelReport, interruptEvent) {
  const heardFraction = cancelReport.totalWordCount
    ? cancelReport.heardWordCount / cancelReport.totalWordCount
    : 0;

  // Rule 1: the interrupting event outright invalidates the instruction's
  // content (e.g. roadblock on the route just referenced, driver explicitly
  // rejects the route). Nothing about the old instruction is worth continuing.
  if (interruptEvent.invalidatesCurrentInstruction) {
    if (interruptEvent.newInstructionText) {
      return {
        action: ACTION.REPLACE,
        reason:
          "Interrupting event invalidates the interrupted instruction's content; a new instruction is available.",
        nextText: interruptEvent.newInstructionText,
      };
    }
    return {
      action: ACTION.DISCARD,
      reason:
        "Interrupting event invalidates the interrupted instruction, and no replacement instruction is ready yet (e.g. rerouting in progress).",
      nextText: null,
    };
  }

  // Rule 2: interrupted extremely early — driver heard little or nothing
  // meaningful (e.g. "In 300 me—"). The instruction is still valid; say it again
  // in full rather than resuming from a fragment, since resuming a near-total
  // fragment is more confusing than a clean repeat.
  if (heardFraction < 0.3) {
    return {
      action: ACTION.REPEAT,
      reason: `Only ${cancelReport.heardWordCount}/${cancelReport.totalWordCount} words were heard before interruption; instruction is still valid, repeating in full.`,
      nextText: cancelReport.fullText,
    };
  }

  // Rule 3: interrupted late, most content already heard, and nothing about
  // the interrupt invalidates it (e.g. driver asked an unrelated question,
  // like "what's the ETA" — ambient interrupt, not a route-relevant one).
  // Resume just the unheard remainder.
  if (heardFraction >= 0.7) {
    return {
      action: ACTION.RESUME,
      reason: `${cancelReport.heardWordCount}/${cancelReport.totalWordCount} words already heard and still valid; resuming with the remainder only.`,
      nextText: cancelReport.unheardText,
    };
  }

  // Rule 4: middle ground — partially heard, still valid, but resuming a
  // mid-sentence fragment would be confusing ("—turn left onto Baker Street"
  // with no subject). Default to a clean repeat rather than an awkward resume.
  return {
    action: ACTION.REPEAT,
    reason: `Partial (${Math.round(heardFraction * 100)}%) heard fragment would be unclear if resumed mid-sentence; repeating in full instead.`,
    nextText: cancelReport.fullText,
  };
}
