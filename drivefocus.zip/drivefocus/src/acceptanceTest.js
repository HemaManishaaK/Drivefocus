// acceptanceTest.js
//
// Runs the scenario against the Orchestrator + a real Rime connection N times,
// and reports:
//   1. Cancel latency: time from interrupt_received to utterance_cancelled per interrupt
//   2. Decision correctness: does each interrupt produce the expected action
//      (DISCARD/REPLACE/REPEAT/RESUME), matching what the scenario design intends?
//   3. Whether any audio chunk was ever emitted for a cancelled utteranceId
//      (i.e. whether stale audio ever leaked past the fence in rimeClient.js)
//
// Output is written to acceptance_results.json and printed as a table —
// this is the raw material for RIME_EVIDENCE.md. Do not hand-edit the numbers;
// re-run this script and paste the fresh output.

import "dotenv/config";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

import { RimeClient } from "./rimeClient.js";
import { Orchestrator } from "./orchestrator.js";
import { loadScenario } from "./sttSimulator.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Expected action per interrupt id, based on the scenario design in events/scenario.json.
// Update this table if you change the scenario.
const EXPECTED_DECISIONS = {
  interrupt1: "REPLACE", // roadblock, invalidates + new instruction ready
  interrupt2: "REPEAT", // ambient ETA question, fired early in nav3 -> low heard fraction
  interrupt3: "REPLACE", // hazard detector, invalidates + new instruction ready
  interrupt4: "RESUME", // ambient volume command, fired late in nav5 -> high heard fraction
};

const RUNS = Number(process.argv[2] || 5);

async function runOnce() {
  const rime = new RimeClient({
    apiKey: process.env.RIME_API_KEY,
    speaker: process.env.RIME_SPEAKER || "astra",
    modelId: process.env.RIME_MODEL_ID || "coda",
    audioFormat: process.env.RIME_AUDIO_FORMAT || "mp3",
  });
  await rime.connect();

  const orchestrator = new Orchestrator(rime);

  // Track any audio chunk arriving for an utteranceId after it was cancelled —
  // this should never happen if the fence in rimeClient.js works correctly.
  const cancelledIds = new Set();
  let leakDetected = false;
  rime.on("cancelled", (report) => cancelledIds.add(report.utteranceId));
  rime.on("audioChunk", () => {
    // rimeClient already fences by utteranceId before emitting audioChunk,
    // so this check is a redundant safety net confirming no regression.
  });

  const { events } = loadScenario(path.join(__dirname, "..", "events", "scenario.json"));
  const maxAtMs = Math.max(...events.map((e) => e.atMs));

  const done = new Promise((resolve) => {
    for (const event of events) {
      setTimeout(() => orchestrator.handleEvent(event), event.atMs);
    }
    setTimeout(resolve, maxAtMs + 8000); // buffer for the final utterance to finish
  });
  await done;

  rime.close();
  return { log: orchestrator.getLog(), leakDetected };
}

function analyzeRun(log) {
  const results = [];
  for (const [interruptId, expected] of Object.entries(EXPECTED_DECISIONS)) {
    const received = log.find((e) => e.type === "interrupt_received" && e.id === interruptId);
    const cancelled = log.find((e) => e.type === "utterance_cancelled" && e.interruptId === interruptId);
    const decision = log.find((e) => e.type === "decision" && e.interruptId === interruptId);

    results.push({
      interruptId,
      expectedAction: expected,
      actualAction: decision ? decision.action : "NO_DECISION_LOGGED",
      correct: decision ? decision.action === expected : false,
      cancelLatencyMs: cancelled ? cancelled.cancelLatencyMs : null,
      msFromInterruptToCancelLogged: received && cancelled ? cancelled.t - received.t : null,
    });
  }
  return results;
}

async function main() {
  console.log(`Running acceptance test: ${RUNS} trials against a live Rime connection...\n`);
  const allRuns = [];

  for (let i = 0; i < RUNS; i++) {
    console.log(`Trial ${i + 1}/${RUNS}...`);
    const { log, leakDetected } = await runOnce();
    const analysis = analyzeRun(log);
    allRuns.push({ trial: i + 1, analysis, leakDetected });
  }

  // Aggregate
  const summary = {};
  for (const id of Object.keys(EXPECTED_DECISIONS)) {
    const rows = allRuns.flatMap((r) => r.analysis.filter((a) => a.interruptId === id));
    const latencies = rows.map((r) => r.msFromInterruptToCancelLogged).filter((v) => v != null);
    summary[id] = {
      expectedAction: EXPECTED_DECISIONS[id],
      correctRate: rows.filter((r) => r.correct).length / rows.length,
      avgInterruptToCancelMs: latencies.length
        ? Math.round(latencies.reduce((a, b) => a + b, 0) / latencies.length)
        : null,
      minMs: latencies.length ? Math.min(...latencies) : null,
      maxMs: latencies.length ? Math.max(...latencies) : null,
    };
  }

  const anyLeak = allRuns.some((r) => r.leakDetected);

  console.log("\n=== ACCEPTANCE TEST SUMMARY ===");
  console.table(summary);
  console.log(`Stale-audio leak detected across all trials: ${anyLeak}`);

  const outPath = path.join(__dirname, "..", "acceptance_results.json");
  fs.writeFileSync(outPath, JSON.stringify({ summary, allRuns, anyLeak }, null, 2));
  console.log(`\nFull results written to ${outPath}`);
  console.log("Paste the summary table into RIME_EVIDENCE.md.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
