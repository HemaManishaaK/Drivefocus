# RIME_EVIDENCE.md

## Hard voice claim

When a high-priority interrupt occurs during a Rime-spoken navigation
instruction, DriveFocus stops the audio within [X]ms of the interrupt being
received, correctly classifies the interrupted instruction's fate
(DISCARD / REPLACE / REPEAT / RESUME) according to a fixed, explainable rule
set, and never allows audio for a cancelled utterance to reach playback after
cancellation.

## Acceptance test

**Procedure** (automated in `src/acceptanceTest.js`, run via `npm run test:acceptance`):

1. Run the scripted scenario (`events/scenario.json`) against a live Rime
   WebSocket connection.
2. For each of the 4 interrupt events, measure:
   - Time from `interrupt_received` to `utterance_cancelled` (cancel latency)
   - The action chosen by `relevanceEngine.decideAction()` vs. the expected
     action defined for that scenario event
   - Whether any audio chunk was emitted for the cancelled utteranceId after
     cancellation (stale-audio leak check)
3. Repeat for 5 trials to check consistency, not just a single lucky run.
4. Report the aggregate table below. Do not hand-edit numbers — regenerate
   by re-running the script and pasting fresh output.

**Normal case:** `interrupt1` — the roadblock example from the problem
statement. Driver interrupts mid-instruction ("...turn left onto—"),
system must REPLACE with the rerouted instruction.

**Stress case:** `interrupt4` — an unrelated ambient command ("turn down the
volume") fired late in a long navigation instruction. This tests that the
system does NOT overreact to every interruption — it must RESUME the
remaining content rather than discarding valid, still-relevant navigation
information over an unrelated driver utterance.

## Results

*(Fill in after running `npm run test:acceptance` against a live Rime API key. Values below are placeholders showing the expected table shape — replace with real measured numbers before submission.)*

| Interrupt ID | Scenario | Expected Action | Decision Correct Rate (5 trials) | Avg Interrupt→Cancel Latency (ms) | Min / Max (ms) |
|---|---|---|---|---|---|
| interrupt1 | Roadblock mid-instruction | REPLACE | TBD | TBD | TBD |
| interrupt2 | Ambient ETA question, early interrupt | REPEAT | TBD | TBD | TBD |
| interrupt3 | Hazard detected while idle | REPLACE | TBD | TBD | TBD |
| interrupt4 | Ambient volume command, late interrupt | RESUME | TBD | TBD | TBD |

**Stale-audio leak detected across all trials:** TBD (must be `false` for
the claim to hold)

## Limitations

- Cancel latency includes local orchestration overhead (event handling,
  the cancel() call) but the moment audio physically stops depends on
  buffered playback in the final client — this test measures the
  *application-level* cancel signal, not end-to-end perceived silence on a
  physical speaker. See README "Known limitations" for the full list.
- The 30%/70% heard-fraction thresholds used to choose REPEAT vs. RESUME are
  a documented heuristic, not empirically validated against real driver
  comprehension.
- Driver speech and hazard detection are scripted inputs (see README
  disclosure) — this evidence validates the interrupt-handling pipeline
  itself, not real-world STT or routing accuracy.
